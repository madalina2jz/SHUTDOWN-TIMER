import os
import platform
import tkinter as tk
from tkinter import messagebox, ttk
import threading
import time

cancel_flag = False  # Global flag to stop countdown

def shutdown_system():
    system = platform.system()
    if system == "Windows":
        os.system("shutdown /s /t 1")
    elif system in ["Linux", "Darwin"]:  # Darwin = macOS
        os.system("shutdown now")
    else:
        messagebox.showerror("Error", "Unsupported OS")

def cancel_shutdown():
    global cancel_flag
    cancel_flag = True
    system = platform.system()
    if system == "Windows":
        os.system("shutdown /a")  # Abort shutdown
    status_label.config(text="Shutdown cancelled.")
    timer_label.config(text="Time left: --:--")
    entry.config(state="normal")
    start_button.config(state="normal")
    unit_menu.config(state="normal")

def start_shutdown_timer():
    global cancel_flag
    cancel_flag = False

    try:
        value = int(entry.get())
        if value <= 0:
            raise ValueError
    except ValueError:
        messagebox.showerror("Invalid Input", "Please enter a valid positive number.")
        return

    unit = unit_var.get()
    total_seconds = 0

    if unit == "Seconds":
        total_seconds = value
    elif unit == "Minutes":
        total_seconds = value * 60
    elif unit == "Hours":
        total_seconds = value * 3600
    elif unit == "Days":
        total_seconds = value * 86400

    # Convert into "next unit" if possible
    display_value = value
    display_unit = unit
    if unit == "Seconds" and value == 60:
        display_value, display_unit = 1, "Minute"
    elif unit == "Minutes" and value == 60:
        display_value, display_unit = 1, "Hour"
    elif unit == "Hours" and value == 24:
        display_value, display_unit = 1, "Day"

    status_label.config(
        text=f"Shutdown scheduled in {display_value} {display_unit}(s)."
    )
    entry.config(state="disabled")
    start_button.config(state="disabled")
    unit_menu.config(state="disabled")

    def countdown():
        nonlocal total_seconds
        while total_seconds > 0 and not cancel_flag:
            mins, secs = divmod(total_seconds, 60)
            hrs, mins = divmod(mins, 60)
            days, hrs = divmod(hrs, 24)

            if days > 0:
                timer_label.config(text=f"Time left: {days}d {hrs:02d}:{mins:02d}:{secs:02d}")
            elif hrs > 0:
                timer_label.config(text=f"Time left: {hrs:02d}:{mins:02d}:{secs:02d}")
            else:
                timer_label.config(text=f"Time left: {mins:02d}:{secs:02d}")

            time.sleep(1)
            total_seconds -= 1

        if not cancel_flag:
            shutdown_system()

    threading.Thread(target=countdown, daemon=True).start()

# GUI setup
root = tk.Tk()
root.title("Shutdown Timer")
root.geometry("350x250")

tk.Label(root, text="Enter time before shutdown:").pack(pady=5)
entry = tk.Entry(root, width=10, justify="center")
entry.pack(pady=5)

# Dropdown for unit selection
unit_var = tk.StringVar(value="Minutes")
unit_menu = ttk.Combobox(root, textvariable=unit_var, values=["Seconds", "Minutes", "Hours", "Days"], state="readonly")
unit_menu.pack(pady=5)

start_button = tk.Button(root, text="Start Timer", command=start_shutdown_timer)
start_button.pack(pady=10)

cancel_button = tk.Button(root, text="Cancel Shutdown", command=cancel_shutdown, fg="red")
cancel_button.pack(pady=5)

timer_label = tk.Label(root, text="Time left: --:--", font=("Arial", 12))
timer_label.pack(pady=5)

status_label = tk.Label(root, text="", fg="blue")
status_label.pack(pady=5)

root.mainloop()
